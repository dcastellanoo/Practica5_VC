# Matriculas > 2022-11-16 12:26am
https://universe.roboflow.com/vc/matriculas-hpotq

Provided by a Roboflow user
License: CC BY 4.0

